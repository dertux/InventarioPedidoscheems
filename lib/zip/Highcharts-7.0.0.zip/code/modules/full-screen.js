/*
 Highcharts JS v7.0.0 (2018-12-11)
 Advanced Highstock tools

 (c) 2010-2018 Highsoft AS
 Author: Torstein Honsi

 License: www.highcharts.com/license
*/
(function(b){"object"===typeof module&&module.exports?module.exports=b:"function"===typeof define&&define.amd?define(function(){return b}):b("undefined"!==typeof Highcharts?Highcharts:void 0)})(function(b){(function(b){b.FullScreen=function(a){this.init(a.parentNode)};b.FullScreen.prototype={init:function(a){a.requestFullscreen?a.requestFullscreen():a.mozRequestFullScreen?a.mozRequestFullScreen():a.webkitRequestFullscreen?a.webkitRequestFullscreen():a.msRequestFullscreen&&a.msRequestFullscreen()}}})(b)});
//# sourceMappingURL=full-screen.js.map
